from datetime import datetime

class Task:
    def __init__(self, title, description, due_date):
        self.title = title
        self.description = description
        self.due_date = datetime.strptime(due_date, "%Y-%m-%d")
        self.completed = False

    @property
    def is_overdue(self):
        return not self.completed and datetime.now() > self.due_date

    def to_dict(self):
        return {
            "title": self.title,
            "description": self.description,
            "due_date": self.due_date.strftime("%Y-%m-%d"),
            "completed": self.completed
        }

    @staticmethod
    def from_dict(data):
        task = Task(data["title"], data["description"], data["due_date"])
        task.completed = data["completed"]
        return task