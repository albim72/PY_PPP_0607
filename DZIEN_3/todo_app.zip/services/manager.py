import json
from models.task import Task

class TaskManager:
    def __init__(self):
        self.tasks = []

    def add_task(self, task: Task):
        self.tasks.append(task)

    def list_tasks(self, show_all=True):
        for i, task in enumerate(self.tasks):
            if show_all or not task.completed:
                status = "✓" if task.completed else "✗"
                overdue = " (przeterminowane)" if task.is_overdue else ""
                print(f"{i + 1}. [{status}] {task.title}{overdue} – {task.due_date.strftime('%Y-%m-%d')}")

    def complete_task(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index].completed = True
        else:
            print("Nieprawidłowy numer zadania.")

    def save_to_file(self, filename="data/zadania.json"):
        with open(filename, "w", encoding="utf-8") as f:
            json.dump([t.to_dict() for t in self.tasks], f, ensure_ascii=False, indent=4)

    def load_from_file(self, filename="data/zadania.json"):
        try:
            with open(filename, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.tasks = [Task.from_dict(item) for item in data]
        except FileNotFoundError:
            print("Plik z zadaniami nie istnieje. Tworzę nowy.")
            self.tasks = []