from models.task import Task
from services.manager import TaskManager

def main():
    manager = TaskManager()
    manager.load_from_file()

    while True:
        print("\n==== MENU ZADAŃ ====")
        print("1. Dodaj zadanie")
        print("2. Pokaż wszystkie zadania")
        print("3. Oznacz zadanie jako wykonane")
        print("4. Zapisz i zakończ")

        wybor = input("Wybierz opcję: ")

        if wybor == "1":
            tytul = input("Tytuł: ")
            opis = input("Opis: ")
            termin = input("Termin (YYYY-MM-DD): ")
            task = Task(tytul, opis, termin)
            manager.add_task(task)

        elif wybor == "2":
            manager.list_tasks()

        elif wybor == "3":
            manager.list_tasks(show_all=False)
            indeks = int(input("Podaj numer zadania do oznaczenia jako wykonane: ")) - 1
            manager.complete_task(indeks)

        elif wybor == "4":
            manager.save_to_file()
            print("Zapisano. Do zobaczenia!")
            break

        else:
            print("Nieznana opcja.")

if __name__ == "__main__":
    main()