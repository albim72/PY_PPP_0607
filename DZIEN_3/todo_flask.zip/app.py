from flask import Flask, render_template, request, redirect
from models.task import Task
import json
import os

app = Flask(__name__)

DATA_FILE = "tasks.json"
tasks = []

def load_tasks():
    global tasks
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            tasks = [Task.from_dict(item) for item in data]

def save_tasks():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump([t.to_dict() for t in tasks], f, ensure_ascii=False, indent=4)

@app.route("/")
def index():
    return render_template("index.html", tasks=tasks)

@app.route("/add", methods=["POST"])
def add():
    title = request.form["title"]
    description = request.form["description"]
    due_date = request.form["due_date"]
    tasks.append(Task(title, description, due_date))
    save_tasks()
    return redirect("/")

@app.route("/complete/<int:index>")
def complete(index):
    if 0 <= index < len(tasks):
        tasks[index].completed = True
        save_tasks()
    return redirect("/")

if __name__ == "__main__":
    load_tasks()
    app.run(debug=True)