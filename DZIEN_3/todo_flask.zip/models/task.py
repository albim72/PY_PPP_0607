from datetime import datetime

class Task:
    def __init__(self, title, description, due_date, completed=False):
        self.title = title
        self.description = description
        self.due_date = due_date
        self.completed = completed

    @property
    def is_overdue(self):
        return not self.completed and datetime.now() > datetime.strptime(self.due_date, "%Y-%m-%d")

    def to_dict(self):
        return {
            "title": self.title,
            "description": self.description,
            "due_date": self.due_date,
            "completed": self.completed
        }

    @staticmethod
    def from_dict(data):
        return Task(data["title"], data["description"], data["due_date"], data["completed"])