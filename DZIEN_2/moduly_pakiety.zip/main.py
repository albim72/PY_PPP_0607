import math_utils
# from mojpakiet.other.divid import division
from mojpakiet import division
from mojpakiet.basic import add,multiply

def main():
    x = 5
    y = 11
    print(math_utils.square(5))
    print(division(10, 2))
    print(division(10, 0))
    print("_________________________________________")
    print(f"{x}+{y} = {add(x, y)}")
    print(f"{x}*{y} = {multiply(x, y)}")

if __name__ == '__main__':
    main()