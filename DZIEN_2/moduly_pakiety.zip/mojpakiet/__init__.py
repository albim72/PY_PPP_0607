from mojpakiet.other.divid import division
print("ładowanie pakietu mojpakiet...")