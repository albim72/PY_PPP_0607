def division(a,b):
    return a/b if b!=0 else "Nie dziel przez zero!"