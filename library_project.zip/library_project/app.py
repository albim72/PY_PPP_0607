from models.book import Book
from services.manager import BookManager

def main():
    storage_path = 'data/storage.pkl'
    manager = BookManager(storage_path)
    manager.load()

    while True:
        print('\n===== Library Menu =====')
        print('1. Add book')
        print('2. List books')
        print('3. Save & exit')
        choice = input('Choose option (1-3): ').strip()

        if choice == '1':
            title = input('Title: ').strip()
            author = input('Author: ').strip()
            try:
                year = int(input('Year: ').strip())
                price = float(input('Price (PLN): ').strip())
            except ValueError:
                print('Invalid year or price!')
                continue
            book = Book(title, author, year, price)
            manager.add_book(book)
            print('Book added.')

        elif choice == '2':
            books = manager.list_books()
            if not books:
                print('No books in library.')
            else:
                print('\n--- Book List ---')
                for idx, book in enumerate(books, 1):
                    print(f'{idx}. {book}')
        elif choice == '3':
            try:
                manager.save()
                print('Library saved. Goodbye!')
            except Exception as e:
                print(f'Error saving library: {e}')
            break
        else:
            print('Invalid option!')

if __name__ == '__main__':
    main()
