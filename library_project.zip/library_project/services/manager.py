import os
import pickle
from models.book import Book

class BookManager:
    def __init__(self, storage_path):
        self.storage_path = storage_path
        self.books = []

    def add_book(self, book):
        self.books.append(book)

    def list_books(self):
        return self.books

    def save(self):
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        with open(self.storage_path, 'wb') as f:
            pickle.dump(self.books, f)

    def load(self):
        try:
            with open(self.storage_path, 'rb') as f:
                self.books = pickle.load(f)
        except FileNotFoundError:
            self.books = []
        except Exception as e:
            print(f'Error loading data: {e}')
            self.books = []
