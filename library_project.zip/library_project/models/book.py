class Book:
    def __init__(self, title, author, year, price):
        self._title = title
        self._author = author
        self._year = year
        self._price = price

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, value):
        self._title = value

    @property
    def author(self):
        return self._author

    @author.setter
    def author(self, value):
        self._author = value

    @property
    def year(self):
        return self._year

    @year.setter
    def year(self, value):
        self._year = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        self._price = value

    def __str__(self):
        return f'"{self.title}" by {self.author} ({self.year}), price: {self.price:.2f} PLN'
